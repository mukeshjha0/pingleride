<?php
/**
 * setup.php
 * -----------------------------------------------------------
 * RUN THIS ONCE after uploading the site and importing sql/schema.sql.
 * Visit https://pingleride.in/setup.php in your browser, create your
 * admin username + password, then this file deletes itself automatically.
 *
 * If you ever need to reset the admin account, just re-upload this file
 * from your local copy and visit it again.
 * -----------------------------------------------------------
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/db.php';

$pdo = get_db();

// Safety: if an admin already exists, refuse to run (prevents takeover by
// anyone who finds this URL after you've already set up your account).
$existing = $pdo->query('SELECT COUNT(*) AS c FROM admins')->fetch();
$adminExists = $existing && (int)$existing['c'] > 0;

$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$adminExists) {
    $username = trim($_POST['username'] ?? '');
    $password = (string) ($_POST['password'] ?? '');
    $confirm  = (string) ($_POST['confirm'] ?? '');

    if (mb_strlen($username) < 3) {
        $message = 'Username must be at least 3 characters.';
    } elseif (mb_strlen($password) < 8) {
        $message = 'Password must be at least 8 characters.';
    } elseif ($password !== $confirm) {
        $message = 'Passwords do not match.';
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare('INSERT INTO admins (username, password_hash) VALUES (:u, :h)');
        $stmt->execute([':u' => $username, ':h' => $hash]);
        $success = true;

        // Self-delete this file for security now that setup is done.
        @unlink(__FILE__);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Pingle Ride — Admin Setup</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body{font-family:'Segoe UI',sans-serif; background:#F7F3EC; color:#1C1B1A; display:flex; align-items:center; justify-content:center; min-height:100vh; margin:0;}
  .box{background:#fff; border-radius:16px; padding:36px; max-width:420px; width:90%; box-shadow:0 14px 32px -16px rgba(0,0,0,0.25);}
  h1{font-size:22px; margin-bottom:6px;}
  p.sub{color:#555; font-size:14px; margin-bottom:24px;}
  label{display:block; font-size:13px; font-weight:600; margin-bottom:6px; margin-top:16px;}
  input{width:100%; padding:10px 12px; border:1.5px solid #ddd; border-radius:8px; font-size:15px;}
  button{margin-top:24px; width:100%; padding:12px; background:#C1440E; color:#fff; border:none; border-radius:8px; font-weight:700; font-size:15px; cursor:pointer;}
  .msg{background:#fdecea; color:#a33; padding:10px 14px; border-radius:8px; font-size:14px; margin-bottom:10px;}
  .ok{background:#e8f5e9; color:#1F4D3A; padding:14px; border-radius:8px; font-size:14px;}
</style>
</head>
<body>
  <div class="box">
    <h1>🚗 Pingle Ride Admin Setup</h1>

    <?php if ($success): ?>
      <p class="ok">✅ Admin account created successfully. This setup page has now deleted itself.<br><br>
      Go to <a href="/admin/">/admin/</a> to log in.</p>
    <?php elseif ($adminExists): ?>
      <p class="ok">An admin account already exists. For security this setup page will not create another one.<br><br>
      Go to <a href="/admin/">/admin/</a> to log in, or delete and re-upload this file if you need to reset.</p>
    <?php else: ?>
      <p class="sub">Create your admin login for the booking dashboard. This page will only work once.</p>
      <?php if ($message): ?><div class="msg"><?= htmlspecialchars($message) ?></div><?php endif; ?>
      <form method="POST">
        <label>Admin Username</label>
        <input type="text" name="username" required minlength="3" placeholder="e.g. owner">
        <label>Password</label>
        <input type="password" name="password" required minlength="8" placeholder="At least 8 characters">
        <label>Confirm Password</label>
        <input type="password" name="confirm" required minlength="8">
        <button type="submit">Create Admin Account</button>
      </form>
    <?php endif; ?>
  </div>
</body>
</html>

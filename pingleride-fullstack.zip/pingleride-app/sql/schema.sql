-- Pingle Ride database schema
-- Import this file via cPanel > phpMyAdmin > Import (or run via SSH mysql client)

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  email VARCHAR(150) DEFAULT NULL,
  pickup_location VARCHAR(255) NOT NULL,
  pickup_date DATE NOT NULL,
  drop_date DATE NOT NULL,
  trip_type ENUM('Self-Drive','With Driver','Airport Transfer','Outstation / Intercity') NOT NULL,
  car_type VARCHAR(50) DEFAULT NULL,
  notes TEXT DEFAULT NULL,
  status ENUM('new','contacted','confirmed','completed','cancelled') NOT NULL DEFAULT 'new',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Simple admin user table (single admin login for the dashboard)
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(60) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- NOTE: No admin row is inserted here on purpose.
-- After importing this file, open setup.php ONCE in your browser
-- (e.g. https://pingleride.in/setup.php) to create your admin username/password.
-- That script then deletes itself automatically for security.

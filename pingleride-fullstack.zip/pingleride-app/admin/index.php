<?php
require_once __DIR__ . '/../config/config.php';
session_start();
$loggedIn = !empty($_SESSION['admin_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard — Pingle Ride</title>
<link href="https://fonts.googleapis.com/css2?family=Archivo+Black&family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
<style>
  :root{
    --ink:#1C1B1A; --paper:#F7F3EC; --paper-dim:#EFE9DC;
    --marigold:#E8A33D; --forest:#1F4D3A; --rust:#C1440E;
    --line:rgba(28,27,26,0.16);
  }
  *{box-sizing:border-box;}
  body{margin:0; background:var(--paper-dim); color:var(--ink); font-family:'Space Grotesk',sans-serif;}
  .mono{font-family:'JetBrains Mono',monospace;}
  a{color:inherit;}

  /* ---- login screen ---- */
  .login-wrap{min-height:100vh; display:flex; align-items:center; justify-content:center;}
  .login-box{background:#fff; padding:40px; border-radius:18px; width:380px; box-shadow:0 14px 32px -16px rgba(0,0,0,0.3);}
  .login-box h1{font-family:'Archivo Black'; font-size:22px; margin:0 0 6px;}
  .login-box p{font-size:13.5px; color:#666; margin:0 0 24px;}
  .login-box label{display:block; font-size:12.5px; font-weight:700; margin:14px 0 6px;}
  .login-box input{width:100%; padding:11px 13px; border:1.5px solid #ddd; border-radius:9px; font-size:15px;}
  .login-box button{margin-top:22px; width:100%; padding:13px; background:var(--rust); color:#fff; border:none; border-radius:9px; font-weight:700; font-size:15px; cursor:pointer;}
  .err{background:#fdecea; color:#a33; padding:10px 13px; border-radius:8px; font-size:13.5px; margin-top:14px; display:none;}

  /* ---- dashboard ---- */
  .topbar{background:var(--ink); color:var(--paper); padding:18px 28px; display:flex; justify-content:space-between; align-items:center;}
  .topbar .brand{font-family:'Archivo Black'; font-size:18px;}
  .topbar .brand span{color:var(--marigold);}
  .logout-btn{background:transparent; border:1px solid rgba(247,243,236,0.4); color:var(--paper); padding:8px 16px; border-radius:999px; font-size:13px; cursor:pointer;}
  .container{max-width:1180px; margin:0 auto; padding:28px;}

  .toolbar{display:flex; gap:14px; flex-wrap:wrap; margin-bottom:22px; align-items:center;}
  .toolbar select, .toolbar input{padding:10px 14px; border-radius:9px; border:1.5px solid var(--line); font-family:'Space Grotesk'; font-size:14px;}
  .toolbar input{flex:1; min-width:200px;}
  .refresh-btn{background:var(--forest); color:#fff; border:none; padding:10px 18px; border-radius:9px; font-weight:700; font-size:13.5px; cursor:pointer;}

  table{width:100%; border-collapse:collapse; background:#fff; border-radius:14px; overflow:hidden; box-shadow:0 6px 18px -10px rgba(0,0,0,0.15);}
  thead{background:var(--ink); color:var(--paper);}
  th, td{padding:13px 14px; text-align:left; font-size:13.5px; border-bottom:1px solid var(--line);}
  th{font-family:'JetBrains Mono'; font-size:11px; text-transform:uppercase; letter-spacing:.06em;}
  tbody tr:hover{background:var(--paper-dim);}
  .badge{font-family:'JetBrains Mono'; font-size:11px; padding:4px 10px; border-radius:999px; text-transform:uppercase; letter-spacing:.04em;}
  .badge-new{background:#fdecea; color:#a33;}
  .badge-contacted{background:#fff4e0; color:#a06b0e;}
  .badge-confirmed{background:#e6f4ea; color:#1F4D3A;}
  .badge-completed{background:#e8eaf6; color:#33408f;}
  .badge-cancelled{background:#eee; color:#777;}
  select.status-select{font-family:'JetBrains Mono'; font-size:12px; padding:6px 8px; border-radius:7px; border:1px solid var(--line);}
  .empty-row{text-align:center; padding:40px; color:#888;}
  .count-pill{font-family:'JetBrains Mono'; font-size:12px; background:var(--marigold); color:var(--ink); padding:5px 12px; border-radius:999px;}
  @media(max-width:760px){
    table, thead, tbody, th, td, tr{display:block;}
    thead{display:none;}
    tr{margin-bottom:14px; border-radius:12px; overflow:hidden; border:1px solid var(--line);}
    td{border-bottom:1px solid var(--line); display:flex; justify-content:space-between; gap:10px;}
    td::before{content: attr(data-label); font-family:'JetBrains Mono'; font-size:10.5px; text-transform:uppercase; opacity:.55; flex-shrink:0;}
  }
</style>
</head>
<body>

<?php if (!$loggedIn): ?>
  <div class="login-wrap">
    <div class="login-box">
      <h1>🚗 Pingle Ride</h1>
      <p>Admin dashboard login</p>
      <form id="loginForm">
        <label>Username</label>
        <input type="text" id="username" required>
        <label>Password</label>
        <input type="password" id="password" required>
        <button type="submit">Log In</button>
        <div class="err" id="loginErr"></div>
      </form>
    </div>
  </div>
  <script>
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const errBox = document.getElementById('loginErr');
      errBox.style.display = 'none';
      const res = await fetch('/api/admin-login.php', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          username: document.getElementById('username').value,
          password: document.getElementById('password').value
        })
      });
      const data = await res.json();
      if (data.ok) {
        window.location.reload();
      } else {
        errBox.textContent = data.message || 'Login failed.';
        errBox.style.display = 'block';
      }
    });
  </script>

<?php else: ?>
  <div class="topbar">
    <div class="brand">Pingle<span>Ride</span> · Admin</div>
    <button class="logout-btn" id="logoutBtn">Log Out</button>
  </div>

  <div class="container">
    <div class="toolbar">
      <select id="statusFilter">
        <option value="">All Statuses</option>
        <option value="new">New</option>
        <option value="contacted">Contacted</option>
        <option value="confirmed">Confirmed</option>
        <option value="completed">Completed</option>
        <option value="cancelled">Cancelled</option>
      </select>
      <input type="text" id="searchBox" placeholder="Search by name, phone or pickup location…">
      <button class="refresh-btn" id="refreshBtn">Refresh</button>
      <span class="count-pill" id="countPill">0 bookings</span>
    </div>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Phone</th>
          <th>Pickup</th>
          <th>Dates</th>
          <th>Trip Type</th>
          <th>Status</th>
          <th>Received</th>
        </tr>
      </thead>
      <tbody id="bookingsBody">
        <tr><td colspan="8" class="empty-row">Loading bookings…</td></tr>
      </tbody>
    </table>
  </div>

  <script>
    const tbody = document.getElementById('bookingsBody');
    const countPill = document.getElementById('countPill');
    const statusFilter = document.getElementById('statusFilter');
    const searchBox = document.getElementById('searchBox');

    async function loadBookings(){
      const params = new URLSearchParams();
      if (statusFilter.value) params.set('status', statusFilter.value);
      if (searchBox.value.trim()) params.set('q', searchBox.value.trim());

      tbody.innerHTML = '<tr><td colspan="8" class="empty-row">Loading…</td></tr>';
      try {
        const res = await fetch('/api/bookings-list.php?' + params.toString());
        const data = await res.json();
        if (!data.ok) {
          tbody.innerHTML = '<tr><td colspan="8" class="empty-row">' + (data.message || 'Failed to load') + '</td></tr>';
          return;
        }
        renderRows(data.bookings);
      } catch(err) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-row">Network error loading bookings.</td></tr>';
      }
    }

    function renderRows(rows){
      countPill.textContent = rows.length + ' booking' + (rows.length === 1 ? '' : 's');
      if (rows.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-row">No bookings found.</td></tr>';
        return;
      }
      tbody.innerHTML = rows.map(b => `
        <tr>
          <td data-label="ID">#${b.id}</td>
          <td data-label="Name">${escapeHtml(b.full_name)}</td>
          <td data-label="Phone"><a href="tel:${escapeHtml(b.phone)}">${escapeHtml(b.phone)}</a></td>
          <td data-label="Pickup">${escapeHtml(b.pickup_location)}</td>
          <td data-label="Dates">${formatDate(b.pickup_date)} → ${formatDate(b.drop_date)}</td>
          <td data-label="Trip Type">${escapeHtml(b.trip_type)}</td>
          <td data-label="Status">
            <select class="status-select" data-id="${b.id}">
              ${['new','contacted','confirmed','completed','cancelled'].map(s =>
                `<option value="${s}" ${s === b.status ? 'selected' : ''}>${s}</option>`
              ).join('')}
            </select>
          </td>
          <td data-label="Received">${formatDateTime(b.created_at)}</td>
        </tr>
      `).join('');

      document.querySelectorAll('.status-select').forEach(sel => {
        sel.addEventListener('change', async () => {
          const id = sel.getAttribute('data-id');
          const status = sel.value;
          await fetch('/api/booking-update.php', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ id, status })
          });
        });
      });
    }

    function escapeHtml(str){
      const div = document.createElement('div');
      div.textContent = str ?? '';
      return div.innerHTML;
    }
    function formatDate(d){
      if(!d) return '-';
      const dt = new Date(d);
      return dt.toLocaleDateString('en-IN', {day:'2-digit', month:'short', year:'numeric'});
    }
    function formatDateTime(d){
      if(!d) return '-';
      const dt = new Date(d.replace(' ', 'T'));
      return dt.toLocaleString('en-IN', {day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit'});
    }

    statusFilter.addEventListener('change', loadBookings);
    document.getElementById('refreshBtn').addEventListener('click', loadBookings);
    searchBox.addEventListener('keyup', (e) => { if(e.key === 'Enter') loadBookings(); });

    document.getElementById('logoutBtn').addEventListener('click', async () => {
      await fetch('/api/admin-logout.php', { method: 'POST' });
      window.location.reload();
    });

    loadBookings();
    setInterval(loadBookings, 30000); // auto-refresh every 30s
  </script>
<?php endif; ?>

</body>
</html>

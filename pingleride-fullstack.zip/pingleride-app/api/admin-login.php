<?php
/**
 * api/admin-login.php
 * Handles admin login form submission. Sets a session on success.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(false, 'Invalid request method.', 405);
}

$input = $_POST;
$raw = file_get_contents('php://input');
if (empty($input) && !empty($raw)) {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) $input = $decoded;
}

$username = trim($input['username'] ?? '');
$password = (string) ($input['password'] ?? '');

if ($username === '' || $password === '') {
    json_response(false, 'Username and password are required.', 422);
}

// Basic brute-force slowdown
sleep(1);

try {
    $pdo = get_db();
    $stmt = $pdo->prepare('SELECT id, username, password_hash FROM admins WHERE username = :u LIMIT 1');
    $stmt->execute([':u' => $username]);
    $admin = $stmt->fetch();
} catch (Throwable $e) {
    error_log('Admin login DB error: ' . $e->getMessage());
    json_response(false, 'Server error. Please try again.', 500);
}

if (!$admin || !password_verify($password, $admin['password_hash'])) {
    json_response(false, 'Invalid username or password.', 401);
}

session_regenerate_id(true);
$_SESSION['admin_id'] = $admin['id'];
$_SESSION['admin_username'] = $admin['username'];

json_response(true, 'Logged in successfully.');

<?php
/**
 * api/booking-update.php
 * Updates a booking's status (e.g. new -> contacted -> confirmed -> completed/cancelled).
 * Requires admin session. POST { id, status }
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');
require_admin_session();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(false, 'Invalid request method.', 405);
}

$input = $_POST;
$raw = file_get_contents('php://input');
if (empty($input) && !empty($raw)) {
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) $input = $decoded;
}

$id = (int) ($input['id'] ?? 0);
$status = trim($input['status'] ?? '');
$validStatuses = ['new', 'contacted', 'confirmed', 'completed', 'cancelled'];

if ($id <= 0 || !in_array($status, $validStatuses, true)) {
    json_response(false, 'Invalid booking id or status.', 422);
}

try {
    $pdo = get_db();
    $stmt = $pdo->prepare('UPDATE bookings SET status = :status WHERE id = :id');
    $stmt->execute([':status' => $status, ':id' => $id]);
} catch (Throwable $e) {
    error_log('booking-update error: ' . $e->getMessage());
    json_response(false, 'Could not update booking.', 500);
}

json_response(true, 'Booking updated.');

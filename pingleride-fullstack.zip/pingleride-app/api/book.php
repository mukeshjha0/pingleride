<?php
/**
 * api/book.php
 * Receives the booking form (POST, JSON or form-encoded), validates it,
 * saves it to the database, and triggers email + (optional) WhatsApp notification.
 *
 * Frontend calls this via fetch('/api/book.php', { method: 'POST', body: ... })
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(false, 'Invalid request method.', 405);
}

// Accept both JSON body and normal form submissions
$input = $_POST;
$rawBody = file_get_contents('php://input');
if (empty($input) && !empty($rawBody)) {
    $decoded = json_decode($rawBody, true);
    if (is_array($decoded)) {
        $input = $decoded;
    }
}

// ----- Basic spam guard: simple honeypot field -----
if (!empty($input['website'] ?? '')) {
    // bots tend to fill hidden fields — pretend success, do nothing
    json_response(true, 'Booking received.');
}

// ----- Validate required fields -----
$fullName       = trim($input['full_name'] ?? '');
$phone          = trim($input['phone'] ?? '');
$email          = trim($input['email'] ?? '');
$pickupLocation = trim($input['pickup_location'] ?? '');
$pickupDate     = trim($input['pickup_date'] ?? '');
$dropDate       = trim($input['drop_date'] ?? '');
$tripType       = trim($input['trip_type'] ?? '');
$carType        = trim($input['car_type'] ?? '');
$notes          = trim($input['notes'] ?? '');

$errors = [];

if ($fullName === '' || mb_strlen($fullName) < 2) {
    $errors['full_name'] = 'Please enter your full name.';
}
if (!preg_match('/^[0-9+\-\s()]{8,16}$/', $phone)) {
    $errors['phone'] = 'Please enter a valid phone number.';
}
if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Please enter a valid email address.';
}
if ($pickupLocation === '') {
    $errors['pickup_location'] = 'Please enter a pickup location.';
}
$validTripTypes = ['Self-Drive', 'With Driver', 'Airport Transfer', 'Outstation / Intercity'];
if (!in_array($tripType, $validTripTypes, true)) {
    $errors['trip_type'] = 'Please choose a valid trip type.';
}
$pickupTs = strtotime($pickupDate);
$dropTs   = strtotime($dropDate);
if (!$pickupDate || $pickupTs === false) {
    $errors['pickup_date'] = 'Please choose a valid pickup date.';
}
if (!$dropDate || $dropTs === false) {
    $errors['drop_date'] = 'Please choose a valid drop date.';
}
if (empty($errors['pickup_date']) && empty($errors['drop_date']) && $dropTs < $pickupTs) {
    $errors['drop_date'] = 'Drop date cannot be before pickup date.';
}

if (!empty($errors)) {
    json_response(false, 'Please fix the highlighted fields.', 422, ['fields' => $errors]);
}

// ----- Save to database -----
try {
    $pdo = get_db();
    $stmt = $pdo->prepare(
        'INSERT INTO bookings
            (full_name, phone, email, pickup_location, pickup_date, drop_date, trip_type, car_type, notes, status)
         VALUES
            (:full_name, :phone, :email, :pickup_location, :pickup_date, :drop_date, :trip_type, :car_type, :notes, "new")'
    );
    $stmt->execute([
        ':full_name'       => $fullName,
        ':phone'           => $phone,
        ':email'           => $email !== '' ? $email : null,
        ':pickup_location' => $pickupLocation,
        ':pickup_date'     => date('Y-m-d', $pickupTs),
        ':drop_date'       => date('Y-m-d', $dropTs),
        ':trip_type'       => $tripType,
        ':car_type'        => $carType !== '' ? $carType : null,
        ':notes'           => $notes !== '' ? $notes : null,
    ]);
    $bookingId = (int) $pdo->lastInsertId();
} catch (Throwable $e) {
    error_log('Booking insert failed: ' . $e->getMessage());
    json_response(false, 'Something went wrong saving your booking. Please call us directly.', 500);
}

// ----- Fire notifications (failures here must NOT block the booking success) -----
$bookingData = [
    'id'              => $bookingId,
    'full_name'       => $fullName,
    'phone'           => $phone,
    'email'           => $email,
    'pickup_location' => $pickupLocation,
    'pickup_date'     => date('d M Y', $pickupTs),
    'drop_date'       => date('d M Y', $dropTs),
    'trip_type'       => $tripType,
    'car_type'        => $carType,
    'notes'           => $notes,
];

try {
    send_booking_email($bookingData);
} catch (Throwable $e) {
    error_log('Booking email failed: ' . $e->getMessage());
}

try {
    send_whatsapp_notification($bookingData);
} catch (Throwable $e) {
    error_log('WhatsApp notification failed: ' . $e->getMessage());
}

json_response(true, 'Thanks! Your booking request has been received. We will call you shortly to confirm.', 200, [
    'booking_id' => $bookingId,
]);

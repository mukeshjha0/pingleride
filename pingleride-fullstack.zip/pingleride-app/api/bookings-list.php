<?php
/**
 * api/bookings-list.php
 * Returns bookings as JSON for the admin dashboard. Requires admin session.
 * Supports optional ?status=new|contacted|confirmed|completed|cancelled and ?q=search
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');
require_admin_session();

$pdo = get_db();

$status = trim($_GET['status'] ?? '');
$q = trim($_GET['q'] ?? '');

$sql = 'SELECT * FROM bookings WHERE 1=1';
$params = [];

$validStatuses = ['new', 'contacted', 'confirmed', 'completed', 'cancelled'];
if ($status !== '' && in_array($status, $validStatuses, true)) {
    $sql .= ' AND status = :status';
    $params[':status'] = $status;
}

if ($q !== '') {
    $sql .= ' AND (full_name LIKE :q OR phone LIKE :q OR pickup_location LIKE :q)';
    $params[':q'] = '%' . $q . '%';
}

$sql .= ' ORDER BY created_at DESC LIMIT 500';

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
} catch (Throwable $e) {
    error_log('bookings-list error: ' . $e->getMessage());
    json_response(false, 'Could not load bookings.', 500);
}

json_response(true, 'ok', 200, ['bookings' => $rows]);

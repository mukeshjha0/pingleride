<?php
/**
 * api/admin-logout.php
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/helpers.php';

header('Content-Type: application/json');
session_start();
$_SESSION = [];
session_destroy();

json_response(true, 'Logged out.');

<?php
/**
 * api/helpers.php
 * Shared utility functions used across API endpoints.
 */

require_once __DIR__ . '/../config/config.php';

/**
 * Send a standard JSON response and stop execution.
 */
function json_response(bool $ok, string $message, int $httpCode = 200, array $extra = []): void {
    http_response_code($httpCode);
    echo json_encode(array_merge(['ok' => $ok, 'message' => $message], $extra));
    exit;
}

/**
 * Send a plain-text booking notification email using PHP's native mail().
 * NOTE: On most shared hosting, mail() works out of the box using the
 * server's local mail transport tied to your domain (no SMTP setup needed),
 * but deliverability is best if your host's "from" domain matches pingleride.in.
 * If you prefer guaranteed delivery via SMTP, see send_booking_email_smtp()
 * below (requires PHPMailer — instructions in README.md).
 */
function send_booking_email(array $b): bool {
    if (!filter_var(OWNER_EMAIL, FILTER_VALIDATE_EMAIL)) {
        return false; // not configured yet
    }

    $subject = '🚗 New Booking Request #' . $b['id'] . ' — ' . SITE_NAME;

    $lines = [
        "New booking request received on " . SITE_NAME . ":",
        "",
        "Booking ID:        #" . $b['id'],
        "Name:              " . $b['full_name'],
        "Phone:             " . $b['phone'],
        "Email:             " . ($b['email'] ?: '-'),
        "Pickup Location:   " . $b['pickup_location'],
        "Pickup Date:       " . $b['pickup_date'],
        "Drop Date:         " . $b['drop_date'],
        "Trip Type:         " . $b['trip_type'],
        "Car Preference:    " . ($b['car_type'] ?: '-'),
        "Notes:             " . ($b['notes'] ?: '-'),
        "",
        "Reply to the customer by phone or WhatsApp: " . $b['phone'],
        "",
        "View all bookings: " . SITE_URL . "/admin/",
    ];
    $body = implode("\n", $lines);

    $fromDomain = parse_url(SITE_URL, PHP_URL_HOST) ?: 'pingleride.in';
    $headers = [
        'From: ' . SITE_NAME . ' Bookings <noreply@' . $fromDomain . '>',
        'Reply-To: ' . ($b['email'] ?: OWNER_EMAIL),
        'Content-Type: text/plain; charset=UTF-8',
    ];

    // Native mail() — works on most shared hosting without extra setup.
    return @mail(OWNER_EMAIL, $subject, $body, implode("\r\n", $headers));
}

/**
 * Optional WhatsApp notification via Twilio's WhatsApp API.
 * Does nothing (returns false) if Twilio credentials are not filled in
 * in config/config.php — this is intentional so the booking flow never
 * breaks just because WhatsApp isn't configured yet.
 */
function send_whatsapp_notification(array $b): bool {
    if (TWILIO_SID === '' || TWILIO_AUTH_TOKEN === '' || TWILIO_WHATSAPP_FROM === '') {
        return false; // not configured — skip silently
    }

    $message = "New Pingle Ride booking #{$b['id']}\n"
        . "{$b['full_name']} | {$b['phone']}\n"
        . "Pickup: {$b['pickup_location']} on {$b['pickup_date']}\n"
        . "Trip: {$b['trip_type']}";

    $url = "https://api.twilio.com/2010-04-01/Accounts/" . TWILIO_SID . "/Messages.json";

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_USERPWD        => TWILIO_SID . ':' . TWILIO_AUTH_TOKEN,
        CURLOPT_POSTFIELDS     => http_build_query([
            'From' => TWILIO_WHATSAPP_FROM,
            'To'   => TWILIO_WHATSAPP_TO,
            'Body' => $message,
        ]),
        CURLOPT_TIMEOUT => 8,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $httpCode >= 200 && $httpCode < 300;
}

/**
 * Require a valid admin session — used by admin-only API endpoints.
 */
function require_admin_session(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
    if (empty($_SESSION['admin_id'])) {
        json_response(false, 'Not authenticated.', 401);
    }
}

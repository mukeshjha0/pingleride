<?php
/**
 * config/config.php
 * -----------------------------------------------------------
 * FILL IN YOUR REAL HOSTING DETAILS BELOW.
 * This file is included by every API script — do not delete.
 * -----------------------------------------------------------
 */

// ===== DATABASE SETTINGS =====
// Find these in cPanel > MySQL Databases (after creating a DB + user there)
define('DB_HOST', 'localhost');           // usually 'localhost' on shared hosting
define('DB_NAME', 'pingleride_db');        // e.g. yourcpaneluser_pingleride
define('DB_USER', 'pingleride_user');      // e.g. yourcpaneluser_admin
define('DB_PASS', 'CHANGE_ME');            // the password you set in cPanel

// ===== SITE SETTINGS =====
define('SITE_NAME', 'Pingle Ride');
define('SITE_URL', 'https://pingleride.in');
define('OWNER_EMAIL', 'owner@pingleride.in');   // where booking emails are sent
define('OWNER_PHONE_WHATSAPP', '918521667890'); // country code + number, no + or spaces

// ===== SMTP SETTINGS (for sending booking emails) =====
// Most hosts (Hostinger/GoDaddy/Bluehost) give you an email account like
// booking@pingleride.in with its own SMTP host/port/password under
// cPanel > Email Accounts > Connect Devices. Fill those in here.
define('SMTP_HOST', 'mail.pingleride.in');
define('SMTP_PORT', 465);          // 465 for SSL, 587 for TLS
define('SMTP_SECURE', 'ssl');      // 'ssl' or 'tls'
define('SMTP_USER', 'booking@pingleride.in');
define('SMTP_PASS', 'CHANGE_ME');

// ===== WHATSAPP / SMS (OPTIONAL — leave blank to disable) =====
// To actually auto-send a WhatsApp/SMS notification (not just a clickable link),
// you need a provider account. Twilio is the most common. Leave these blank
// and the app will just skip auto-sending — you'll still see every booking
// in the admin dashboard and get the email notification.
define('TWILIO_SID', '');
define('TWILIO_AUTH_TOKEN', '');
define('TWILIO_WHATSAPP_FROM', '');   // e.g. 'whatsapp:+14155238886'
define('TWILIO_WHATSAPP_TO', 'whatsapp:+' . OWNER_PHONE_WHATSAPP);

// ===== SECURITY =====
// Random string used to sign admin login sessions. Change to any long random text.
define('APP_SECRET', 'change_this_to_a_long_random_string_before_going_live');

// ----- Do not edit below this line -----
date_default_timezone_set('Asia/Kolkata');
error_reporting(E_ALL);
ini_set('display_errors', '0'); // keep '0' in production so errors don't leak to users

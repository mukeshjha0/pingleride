# Pingle Ride — Full-Stack Website + Booking System

This folder is a complete, ready-to-upload website for **pingleride.in**:
- A marketing site (`index.html`) with a **working booking form**
- A **PHP + MySQL backend** that saves every booking to a database
- **Email notifications** to you on every new booking
- An optional **WhatsApp notification** (via Twilio — needs a paid account, off by default)
- A simple **admin dashboard** (`/admin/`) to view and manage bookings, with login

No coding experience needed to deploy this — just follow the steps below in order.

---

## 📁 What's in this folder

```
/
├── index.html              ← the website itself (homepage)
├── setup.php                ← run ONCE to create your admin login, then it deletes itself
├── .htaccess                 ← security settings (leave as is)
├── api/
│   ├── book.php              ← receives booking form submissions
│   ├── helpers.php            ← shared functions (email, WhatsApp, JSON responses)
│   ├── admin-login.php        ← admin dashboard login
│   ├── admin-logout.php       ← admin dashboard logout
│   ├── bookings-list.php      ← returns bookings as JSON (used by dashboard)
│   └── booking-update.php     ← updates a booking's status (used by dashboard)
├── admin/
│   └── index.php              ← the admin dashboard page (login screen + booking table)
├── config/
│   ├── config.php              ← ⚠️ YOU MUST EDIT THIS — database + email settings
│   ├── db.php                   ← database connection code (no editing needed)
│   └── .htaccess                ← blocks public access to this folder
└── sql/
    ├── schema.sql                ← database structure to import
    └── .htaccess                  ← blocks public access to this folder
```

---

## 🚀 Deployment steps (cPanel-style hosting — Hostinger, GoDaddy, Bluehost, etc.)

### Step 1 — Create a MySQL database
1. Log in to your hosting control panel (cPanel / hPanel).
2. Find **MySQL Databases** (sometimes called "Database Wizard").
3. Create a new database — note its full name (hosts usually prefix it, e.g. `u123456_pingleride`).
4. Create a new database **user** with a strong password — note the username and password.
5. **Attach the user to the database** with **All Privileges** (this step is easy to miss — without it, the app can't read/write).

### Step 2 — Edit `config/config.php`
Open `config/config.php` in any text editor (Notepad, VS Code, etc.) and fill in:

```php
define('DB_HOST', 'localhost');           // usually stays 'localhost'
define('DB_NAME', 'u123456_pingleride');    // the exact DB name from Step 1
define('DB_USER', 'u123456_admin');         // the exact DB username from Step 1
define('DB_PASS', 'your-real-password');     // the password you set in Step 1

define('OWNER_EMAIL', 'youremail@example.com'); // where booking alerts go
```

Also update `APP_SECRET` to any long random string of your choosing (mash the keyboard — it just needs to be unpredictable).

Leave the Twilio/WhatsApp lines blank for now (see the WhatsApp section below) — the site works perfectly without them.

### Step 3 — Upload everything
1. In cPanel, open **File Manager**.
2. Go into `public_html` (this is the folder your domain `pingleride.in` points to).
3. If there's a placeholder `index.html` already there, delete it.
4. Upload **all files and folders from this package** directly into `public_html`, keeping the same structure (so you end up with `public_html/index.html`, `public_html/api/`, `public_html/admin/`, etc.)
   - Easiest way: zip this whole folder before uploading, use File Manager's **Upload**, then **Extract** the zip directly inside `public_html`.

### Step 4 — Import the database structure
1. In cPanel, open **phpMyAdmin**.
2. Select the database you created in Step 1 (left sidebar).
3. Click the **Import** tab.
4. Choose the file `sql/schema.sql` from this package and click **Go**.
5. You should see two new tables appear: `bookings` and `admins`.

### Step 5 — Create your admin login
1. Visit **`https://pingleride.in/setup.php`** in your browser.
2. Choose a username and password (8+ characters) for the admin dashboard.
3. Submit — you'll see a success message, and `setup.php` deletes itself automatically (so no one else can ever run it again).

### Step 6 — Test the booking form
1. Visit `https://pingleride.in`, scroll to the booking form, and submit a test booking.
2. Check `https://pingleride.in/admin/` and log in with the account from Step 5 — your test booking should appear.
3. Check the inbox of the email you set as `OWNER_EMAIL` — you should receive a notification (check spam folder the first time).

That's it — bookings now flow in automatically. 🎉

---

## ✉️ About email delivery

The app uses PHP's built-in `mail()` function, which works on most shared hosting without any extra setup — but emails can occasionally land in spam, especially on the very first few sends. To improve this:
- In cPanel, go to **Email Accounts** and create an address like `noreply@pingleride.in`.
- This alone often improves deliverability since the "From" domain now matches a real mailbox on your hosting.

If you want guaranteed delivery via your own SMTP, that requires installing the PHPMailer library — let me know if you want this set up and I'll add it.

---

## 📲 About WhatsApp / SMS notifications

There is no free, generic way to auto-send WhatsApp messages — it requires a provider account:
- **Twilio** (most common, supports WhatsApp Business API) — https://www.twilio.com
- Sign up, get WhatsApp sandbox or approved sending number, then fill these into `config/config.php`:

```php
define('TWILIO_SID', 'ACxxxxxxxxxxxxxxxx');
define('TWILIO_AUTH_TOKEN', 'your_auth_token');
define('TWILIO_WHATSAPP_FROM', 'whatsapp:+14155238886'); // Twilio gives you this number
```

Until these are filled in, the app silently skips WhatsApp sending — bookings still save to the database and still email you, so nothing breaks.

---

## 🔒 Security notes

- `config/` and `sql/` folders are blocked from direct web access via `.htaccess` — don't remove those files.
- Change the default `APP_SECRET` in `config.php` before going fully live.
- `setup.php` deletes itself after first use. If you ever need to reset your admin password, re-upload `setup.php` from your local copy of this package and visit it again.
- Once your SSL certificate is active (most hosts auto-issue a free one), uncomment the HTTPS redirect lines at the top of the root `.htaccess` file.

---

## 🛠 Local testing before uploading (optional, for developers)

If you have PHP installed locally:
```bash
php -S localhost:8000
```
Then visit `http://localhost:8000`. You'll still need a local MySQL database matching the schema, and updated `config.php` values pointing to it.

---

## Need changes?

Common things you might want next:
- Real pricing/fleet photos instead of placeholders
- SMTP-based email (instead of native `mail()`) for guaranteed delivery
- Booking confirmation auto-email/SMS sent to the *customer*, not just you
- Export bookings to Excel/CSV from the admin dashboard
- Calendar view of upcoming bookings

Just ask, and these can be added on top of this same structure.
